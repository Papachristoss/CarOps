package AnalushKaiSxediashOmada10;

import java.util.ArrayList;

public class TasksCatalog {

	private ArrayList<Task> TasksCatalog;

	
	
	public TasksCatalog() {
		super();
	}

	public TasksCatalog(ArrayList<Task> tasksCatalog) {
		super();
		TasksCatalog = tasksCatalog;
	}

	public ArrayList<Task> getTasksCatalog() {
		return TasksCatalog;
	}

	public void setTasksCatalog(ArrayList<Task> tasksCatalog) {
		TasksCatalog = tasksCatalog;
	}
	
	
}
