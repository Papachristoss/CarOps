package AnalushKaiSxediashOmada10;

public class VehiclePart {
	
	private String VehiclePartCode;
	private String Name;
	private double Cost;
	
	
	
	public VehiclePart(String type, double price) {
		super();
		this.Name = type;
		this.Cost = price;
	}

	
	public VehiclePart(String vehiclePartCode, String name, double cost) {
		super();
		VehiclePartCode = vehiclePartCode;
		Name = name;
		Cost = cost;
	}


	public VehiclePart() {
		super();
	}








	public double getPrice() {
		return Cost;
	}
	public void setPrice(double price) {
		this.Cost = price;
	}

	public String getVehiclePartCode() {
		return VehiclePartCode;
	}

	public void setVehiclePartCode(String vehiclePartCode) {
		VehiclePartCode = vehiclePartCode;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public double getCost() {
		return Cost;
	}

	public void setCost(double cost) {
		Cost = cost;
	}
	
	
}
