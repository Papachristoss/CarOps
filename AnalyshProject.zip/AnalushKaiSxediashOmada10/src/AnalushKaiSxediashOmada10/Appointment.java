package AnalushKaiSxediashOmada10;

public class Appointment {
	
	private CustomerCard AppointmentCustomerCard;
	private VehicleCard AppointmentVehicleCard;
	private String AppointmentDate;
	
	
	
	
	public Appointment() {
		super();
	}



	public Appointment(CustomerCard appointmentCustomerCard, VehicleCard appointmentVehicleCard,
			String appointmentDate) {
		super();
		AppointmentCustomerCard = appointmentCustomerCard;
		AppointmentVehicleCard = appointmentVehicleCard;
		AppointmentDate = appointmentDate;
	}
	
	
	
	public CustomerCard getAppointmentCustomerCard() {
		return AppointmentCustomerCard;
	}
	public void setAppointmentCustomerCard(CustomerCard appointmentCustomerCard) {
		AppointmentCustomerCard = appointmentCustomerCard;
	}
	public VehicleCard getAppointmentVehicleCard() {
		return AppointmentVehicleCard;
	}
	public void setAppointmentVehicleCard(VehicleCard appointmentVehicleCard) {
		AppointmentVehicleCard = appointmentVehicleCard;
	}
	public String getAppointmentDate() {
		return AppointmentDate;
	}
	public void setAppointmentDate(String appointmentDate) {
		AppointmentDate = appointmentDate;
	}
	
	

}
