package AnalushKaiSxediashOmada10;

import java.util.ArrayList;

public class Customer extends Human {

	private String CustomerID;
	private ArrayList<Vehicle> VehiclesOwned;
	
	public Customer(String name,String surname, String mobilePhoneNumber, String homePhoneNumber, String homeAddress,
			String emailAddress, String birthDate,String cID) {
		super(name,surname, mobilePhoneNumber, homePhoneNumber, homeAddress, emailAddress, birthDate);
		// TODO Auto-generated constructor stub
		CustomerID = cID;
	}
	
	
	public String getCustomerID() {
		return CustomerID;
	}

	public void setCustomerID(String customerID) {
		CustomerID = customerID;
	}


	public ArrayList<Vehicle> getVehiclesOwned() {
		return VehiclesOwned;
	}

	public void setVehiclesOwned(ArrayList<Vehicle> vehiclesOwned) {
		VehiclesOwned = vehiclesOwned;
	}

	
	public void MakePayment(Payment payment) {
		//make payment 
	}
}
