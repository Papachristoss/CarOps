package AnalushKaiSxediashOmada10;

public class InformationSystemUser {
	
	private Account Account;
	private String UserID;
	
	
	
	public InformationSystemUser(AnalushKaiSxediashOmada10.Account account, String userID) {
		super();
		Account = account;
		UserID = userID;
	}

	public Account getAccount() {
		return Account;
	}

	public void setAccount(Account account) {
		Account = account;
	}

	public String getUserID() {
		return UserID;
	}

	public void setUserID(String userID) {
		UserID = userID;
	}

	public void Login(String Username, String Password) {}

}
