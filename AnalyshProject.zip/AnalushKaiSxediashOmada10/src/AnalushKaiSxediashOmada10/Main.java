package AnalushKaiSxediashOmada10;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Task ergasia1 = new Task("Αλλαγή Λαδιών",20 );
		Task ergasia2 = new Task("Αλλαγή φίλτρου καμπίνας", 5 );
		Task ergasia3 = new Task("Συντήρηση φρένων", 30);
		
        VehiclePart tuposAntalaktikon1 = new VehiclePart("Συσκευασία λαδιών 4lt",30);
        VehiclePart tuposAntalaktikon2 = new VehiclePart("Φίλτρο λαδιού",20);
        VehiclePart tuposAntalaktikon3 = new VehiclePart("Φίλτρο καμπίνας",30);
        VehiclePart tuposAntalaktikon4 = new VehiclePart("Τακάκι φρένων εμπρός τροχού",5);
        VehiclePart tuposAntalaktikon5 = new VehiclePart("Τακάκι φρένων πίσω τροχού",5);
        VehiclePart tuposAntalaktikon6 = new VehiclePart("Υγρό φρένων",10);
		
		ergasia1.addItem(tuposAntalaktikon1);
		ergasia1.addItem(tuposAntalaktikon2);
		ergasia2.addItem(tuposAntalaktikon3);
		ergasia3.addItem(tuposAntalaktikon4);
		ergasia3.addItem(tuposAntalaktikon4);
		ergasia3.addItem(tuposAntalaktikon4);
		ergasia3.addItem(tuposAntalaktikon4);
		ergasia3.addItem(tuposAntalaktikon5);
		ergasia3.addItem(tuposAntalaktikon5);
		ergasia3.addItem(tuposAntalaktikon5);
		ergasia3.addItem(tuposAntalaktikon5);
		ergasia3.addItem(tuposAntalaktikon6);
		
		Project episkevi1 = new Project();
		Project episkevi2 = new Project();
		Project episkevix = new Project();
		
		episkevix.addItem("Συσκευασία λαδιών 4lt 30€");
        episkevix.addItem("Φίλτρο λαδιού 20€");
        episkevix.addItem("Φίλτρο καμπίνας 30€");
        episkevix.addItem("Τακάκι φρένων εμπρός τροχού 5€");
        episkevix.addItem("Τακάκι φρένων πίσω τροχού 5€");
        episkevix.addItem("Υγρό φρένων 10€");
		
		
		episkevi1.addItem(ergasia1);
		episkevi1.addItem(ergasia2);
		episkevi2.addItem(ergasia3);
		episkevi1.setDuration(1);
		episkevi2.setDuration(2);
		
		System.out.println(ergasia1.getName()+" "+ergasia1.getPrice()+"€");
		System.out.println(ergasia2.getName()+" "+ergasia2.getPrice()+"€");
		System.out.println(ergasia3.getName()+" "+ergasia3.getPrice()+"€");

		episkevix.itemNames();
		
		System.out.println("Επισκευή 1:"+" Διάρκεια:"+episkevi1.getDuration()+"Μέρα Kόστος:"+ episkevi1.getTotalCost()+"€");
        System.out.println("Επισκευή 2:"+" Διάρκεια:"+episkevi2.getDuration()+"Μέρες Kόστος:"+ episkevi2.getTotalCost()+"€");
	}

}
