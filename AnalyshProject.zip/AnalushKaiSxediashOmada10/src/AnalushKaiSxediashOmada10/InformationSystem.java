package AnalushKaiSxediashOmada10;

import java.util.ArrayList;

public class InformationSystem {

	private String Version;
	private VehicleRepairShop VehicleRepairShop;
	private FrontDesk FrontDesk;

	private AccountsCatalog AccountsCatalog;
	private AppointmentCatalog AppointmentCatalog;
	private RepairsFolderCatalog RepairsFolderCatalog;
	private CatalogOfCustomerCards CatalogOfCustomerCards;
	private CatalogOfVehicleCards CatalogOfVehicleCards;
	private ProjectsCatalog ProjectsCatalog;
	private TasksCatalog TasksCatalog;
	private ArrayList<InformationSystemUser> InformationSystemUsers;
	private ArrayList<Report> MonthlyReports;
	
	
	
	
	//METHODS OF INFORMATION SYSTEM
	public void Login(String username, String Password) {
		//Logs Into Account
	}
	public Account CreateAccount(Employee owner, String username, String password, String type) {
		//Creates Account
		Account CreatedAccount = new Account(owner,username,password,type);
		return CreatedAccount;
	}
	public Appointment CreateNewAppointment() {
		Appointment CreatedAppointment = new Appointment();
		return CreatedAppointment;
		//Created new Appointment
	}
	public void CatalogueVehicle(VehicleCard VehicleCard, Vehicle Vehicle) {
		//Catalogs Vehicle to system 
		this.CatalogOfVehicleCards.addVehicleCard(VehicleCard);
	}
	public void SendUpdateEmailForAppointment() {
		//Sends Update Email For Appointment 
	}
	public CustomerCard CreateCustomerCard() {
		CustomerCard CreatedCustomerCard= new CustomerCard();
		return CreatedCustomerCard;
	}
	public VehicleCard CreateVehicleCard() {
		VehicleCard CreatedVehicleCard= new VehicleCard();
		return CreatedVehicleCard;
	}
	public RepairsFolder CreateRepairsFolder() {
		//Creates RepairsFolder 
		RepairsFolder CreatedRepairsFolder = new RepairsFolder();
		return CreatedRepairsFolder;
	}
	public void AddTaskNeededForRepair(RepairsFolder RepairsFolder,Task Task) {
		//Adds Passed Task to Passed RepairsFolder
		RepairsFolder.AddTask(Task);
		
	}
	public void SubmitRepairsFolder(RepairsFolder RepairsFolder) {
		//Submits Repairs Folder to System
	}
	public double CalculateRepairsCost(RepairsFolder RepairsFolder) {
		return RepairsFolder.CalculateCost();
		//Calculates Total Cost of Repair Folder
	}
	public void SearchRepairFolder(RepairsFolder RepairsFolder) {
		//Searches for particular repairs Folder in system 
	}
	public void PrintRepairFolder(RepairsFolder RepairsFolder) {
		//System Prints Physical Repair Folder For Customer  
	}
	public void SendRepairFolderEmail(RepairsFolder RepairsFolder,String email) {
		//Sends Repair Folder To Customer when Repair is Complete
	}
	public void ShowCompletedRepairs() {
		//System Shows All Completed Repairs
	}
	public void InformSystemAboutRepair(RepairsFolder RepairsFolder, boolean condition) {
		//System is informed about the state of a repair
	}
	public void RecordAssignedTasks(Mechanic Mechanic, Task Task) {
		//Mechanic Records the Tasks that he Completed from his Assigned Tasks
	}
	public void SeeAssignedTasks(Mechanic Mechanic) {
		//Mechanic Sees The Tasks That Are Assigned to him
	}
	

	
	public void RecordTimeNeededForRepair(int time,RepairsFolder RepairsFolder) {
		//RecordsPartsNeededForRepair
	}
	public void RecordPartsNeededForRepair(ArrayList<VehiclePart> PartsNeeded,RepairsFolder RepairsFolder) {
		//RecordsPartsNeededForRepair
	}
	public void PrintReceit(Payment Payment) {
		//Prints receipt of Passed Payment 
	}
	
	public void ViewMonthlyReports(ArrayList<Report> Reports) {
		//Views Monthly Reports
	}
	public void SelectReportToSee(ArrayList<Report> Reports) {
		//Selects Which Report Manager is interested to See
	}
	public void SelectMonthOfReport(int month) {
		//Selects Month of report
	}
	public void ReturnToMonthlyReports(){
		//Returns To Monthly Reports Menu
	}
	public void ExitReport() {
		//Exits Reports Menu
	}
	
	
	
	//GETTERS AND SETTERS
	public String getVersion() {
		return Version;
	}

	public void setVersion(String version) {
		Version = version;
	}

	public VehicleRepairShop getVehicleRepairShop() {
		return VehicleRepairShop;
	}

	public void setVehicleRepairShop(VehicleRepairShop vehicleRepairShop) {
		VehicleRepairShop = vehicleRepairShop;
	}

	public FrontDesk getFrontDesk() {
		return FrontDesk;
	}

	public void setFrontDesk(FrontDesk frontDesk) {
		FrontDesk = frontDesk;
	}

	public AccountsCatalog getAccountsCatalog() {
		return AccountsCatalog;
	}

	public void setAccountsCatalog(AccountsCatalog accountsCatalog) {
		AccountsCatalog = accountsCatalog;
	}

	public AppointmentCatalog getAppointmentCatalog() {
		return AppointmentCatalog;
	}

	public void setAppointmentCatalog(AppointmentCatalog appointmentCatalog) {
		AppointmentCatalog = appointmentCatalog;
	}

	public RepairsFolderCatalog getRepairsFolderCatalog() {
		return RepairsFolderCatalog;
	}

	public void setRepairsFolderCatalog(RepairsFolderCatalog repairsFolderCatalog) {
		RepairsFolderCatalog = repairsFolderCatalog;
	}

	public CatalogOfCustomerCards getCatalogOfCustomerCards() {
		return CatalogOfCustomerCards;
	}

	public void setCatalogOfCustomerCards(CatalogOfCustomerCards catalogOfCustomerCards) {
		CatalogOfCustomerCards = catalogOfCustomerCards;
	}

	public CatalogOfVehicleCards getCatalogOfVehicleCards() {
		return CatalogOfVehicleCards;
	}

	public void setCatalogOfVehicleCards(CatalogOfVehicleCards catalogOfVehicleCards) {
		CatalogOfVehicleCards = catalogOfVehicleCards;
	}

	public ProjectsCatalog getProjectsCatalog() {
		return ProjectsCatalog;
	}

	public void setProjectsCatalog(ProjectsCatalog projectsCatalog) {
		ProjectsCatalog = projectsCatalog;
	}

	public TasksCatalog getTasksCatalog() {
		return TasksCatalog;
	}

	public void setTasksCatalog(TasksCatalog tasksCatalog) {
		TasksCatalog = tasksCatalog;
	}

	public ArrayList<InformationSystemUser> getInformationSystemUsers() {
		return InformationSystemUsers;
	}

	public void setInformationSystemUsers(ArrayList<InformationSystemUser> informationSystemUsers) {
		InformationSystemUsers = informationSystemUsers;
	}
	public ArrayList<Report> getMonthlyReports() {
		return MonthlyReports;
	}
	public void setMonthlyReports(ArrayList<Report> monthlyReports) {
		MonthlyReports = monthlyReports;
	}
	
	
}
