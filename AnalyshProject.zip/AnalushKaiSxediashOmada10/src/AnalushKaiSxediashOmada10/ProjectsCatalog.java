package AnalushKaiSxediashOmada10;

import java.util.ArrayList;

public class ProjectsCatalog {

	private ArrayList<Project> ProjectsCatalog;

	public ProjectsCatalog(ArrayList<Project> projectsCatalog) {
		super();
		ProjectsCatalog = projectsCatalog;
	}

	public ProjectsCatalog() {
		super();
	}

	public ArrayList<Project> getProjectsCatalog() {
		return ProjectsCatalog;
	}

	public void setProjectsCatalog(ArrayList<Project> projectsCatalog) {
		ProjectsCatalog = projectsCatalog;
	}
	
	
}
