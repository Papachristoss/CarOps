package AnalushKaiSxediashOmada10;

import java.util.ArrayList;

public class RepairsFolder {

	private CustomerCard RepairsFolderCustomerCard;
	private VehicleCard RepairsFolderVecicleCard;
	private ArrayList<Task> RepairsFolderTasksNeeded;
	private Project RepairsFolderProject;
	private int FolderID;
	private double Cost;
	
	
	public RepairsFolder() {
		super();
	}
	
	public RepairsFolder(CustomerCard repairsFolderCustomerCard, VehicleCard repairsFolderVecicleCard,
			ArrayList<Task> repairsFolderTasksNeeded, Project repairsFolderProject, int folderID, double cost) {
		super();
		RepairsFolderCustomerCard = repairsFolderCustomerCard;
		RepairsFolderVecicleCard = repairsFolderVecicleCard;
		RepairsFolderTasksNeeded = repairsFolderTasksNeeded;
		RepairsFolderProject = repairsFolderProject;
		FolderID = folderID;
		Cost = cost;
	}
	public CustomerCard getRepairsFolderCustomerCard() {
		return RepairsFolderCustomerCard;
	}
	public void setRepairsFolderCustomerCard(CustomerCard repairsFolderCustomerCard) {
		RepairsFolderCustomerCard = repairsFolderCustomerCard;
	}
	public VehicleCard getRepairsFolderVecicleCard() {
		return RepairsFolderVecicleCard;
	}
	public void setRepairsFolderVecicleCard(VehicleCard repairsFolderVecicleCard) {
		RepairsFolderVecicleCard = repairsFolderVecicleCard;
	}
	public ArrayList<Task> getRepairsFolderTasksNeeded() {
		return RepairsFolderTasksNeeded;
	}
	public void setRepairsFolderTasksNeeded(ArrayList<Task> repairsFolderTasksNeeded) {
		RepairsFolderTasksNeeded = repairsFolderTasksNeeded;
	}
	public Project getRepairsFolderProject() {
		return RepairsFolderProject;
	}
	public void setRepairsFolderProject(Project repairsFolderProject) {
		RepairsFolderProject = repairsFolderProject;
	}
	public int getFolderID() {
		return FolderID;
	}
	public void setFolderID(int folderID) {
		FolderID = folderID;
	}
	public double getCost() {
		return Cost;
	}
	public void setCost(double cost) {
		Cost = cost;
	}
	
	public void AddTask(Task Task) {
		this.RepairsFolderTasksNeeded.add(Task);
	}

	public double CalculateCost() {
		// TODO Auto-generated method stub
		return this.Cost;
	}
	
}
