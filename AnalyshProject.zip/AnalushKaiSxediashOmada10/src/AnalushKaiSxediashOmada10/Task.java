package AnalushKaiSxediashOmada10;

import java.util.ArrayList;

public class Task {
	private String name; 
	private double price;
	private ArrayList<VehiclePart> antalaktika = new ArrayList();
	
	public Task(String name, double price) {
		super();
		this.name = name;
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	public void addItem(VehiclePart type) {
		antalaktika.add(type);
	}
	
	public double totalCost() {
		double cost1 = 0;
		for (VehiclePart type : antalaktika) {
			cost1 = cost1 +type.getPrice();
		}
		cost1 = cost1+price;
		return cost1;
	}
	

	
	
}
