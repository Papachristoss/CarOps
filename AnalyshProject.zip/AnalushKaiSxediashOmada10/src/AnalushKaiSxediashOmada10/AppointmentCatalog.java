package AnalushKaiSxediashOmada10;

import java.util.ArrayList;

public class AppointmentCatalog {

	ArrayList<Appointment> AppointmentCatalog;

	
	
	public AppointmentCatalog() {
		super();
	}

	public AppointmentCatalog(ArrayList<Appointment> appointmentCatalog) {
		super();
		AppointmentCatalog = appointmentCatalog;
	}

	public ArrayList<Appointment> getAppointmentCatalog() {
		return AppointmentCatalog;
	}

	public void setAppointmentCatalog(ArrayList<Appointment> appointmentCatalog) {
		AppointmentCatalog = appointmentCatalog;
	}
	
}
