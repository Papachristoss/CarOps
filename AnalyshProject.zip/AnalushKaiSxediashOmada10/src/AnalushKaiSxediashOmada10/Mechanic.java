package AnalushKaiSxediashOmada10;

public class Mechanic extends Employee {

	private boolean Experienced;
	
	public Mechanic() {
		super();
	}

	public Mechanic(String name, String surname, String mobilePhoneNumber, String homePhoneNumber, String homeAddress,
			String emailAddress, String birthDate, String aFM, int yearsWorkingInCurrentBusiness, int yearsOfExperience,
			String employmentRole, double salary, String cV, boolean experienced) {
		super(name, surname, mobilePhoneNumber, homePhoneNumber, homeAddress, emailAddress, birthDate, aFM,
				yearsWorkingInCurrentBusiness, yearsOfExperience, employmentRole, salary, cV);
		Experienced = experienced;
	}

	public boolean isExperienced() {
		return Experienced;
	}

	public void setExperienced(boolean experienced) {
		Experienced = experienced;
	}

	public Mechanic(String name, String surname, String mobilePhoneNumber, String homePhoneNumber, String homeAddress,
			String emailAddress, String birthDate, String aFM, int yearsWorkingInCurrentBusiness, int yearsOfExperience,
			String employmentRole, double salary, String cV) {
		super(name, surname, mobilePhoneNumber, homePhoneNumber, homeAddress, emailAddress, birthDate, aFM,
				yearsWorkingInCurrentBusiness, yearsOfExperience, employmentRole, salary, cV);
		// TODO Auto-generated constructor stub
	}

	public void AssignTaskToMechanic(Task task) {
		//Adds Passed Task to this Mechanic
	}
}
