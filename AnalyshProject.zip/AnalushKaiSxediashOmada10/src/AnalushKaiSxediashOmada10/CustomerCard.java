package AnalushKaiSxediashOmada10;

public class CustomerCard {


	private String CustomerID;
	private String CustomerName;
	private String CustomerSurname;
	private String CustomerHomePhoneNumber;
	private String CustomerMobilePhoneNumber;
	private String CustomerHomeAddress;
	private String CustomerEmail;
	private String CustomerCardID;

	private Customer CorrespondingCustomer;

	public CustomerCard(String customerID, String customerName, String customerSurname, String customerHomePhoneNumber,
			String customerMobilePhoneNumber, String customerHomeAddress, String customerEmail, String customerCardID) {
		super();
		CustomerID = customerID;
		CustomerName = customerName;
		CustomerSurname = customerSurname;
		CustomerHomePhoneNumber = customerHomePhoneNumber;
		CustomerMobilePhoneNumber = customerMobilePhoneNumber;
		CustomerHomeAddress = customerHomeAddress;
		CustomerEmail = customerEmail;
		CustomerCardID = customerCardID;
	}
	
	public CustomerCard(Customer customer) {
		CorrespondingCustomer=customer;
		CustomerID = customer.getCustomerID();
		CustomerName = customer.getName();
		CustomerSurname = customer.getSurname();
		CustomerHomePhoneNumber = customer.getHomePhoneNumber();
		CustomerMobilePhoneNumber = customer.getMobilePhoneNumber();
		CustomerHomeAddress = customer.getHomeAddress();
		CustomerEmail = customer.getEmailAddress();
		CustomerCardID = customer.getCustomerID();
	}
	
	public CustomerCard() {
		// TODO Auto-generated constructor stub
	}

	public String getCustomerID() {
		return CustomerID;
	}

	public void setCustomerID(String customerID) {
		CustomerID = customerID;
	}

	public String getCustomerName() {
		return CustomerName;
	}

	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}

	public String getCustomerSurname() {
		return CustomerSurname;
	}

	public void setCustomerSurname(String customerSurname) {
		CustomerSurname = customerSurname;
	}

	public String getCustomerHomePhoneNumber() {
		return CustomerHomePhoneNumber;
	}

	public void setCustomerHomePhoneNumber(String customerHomePhoneNumber) {
		CustomerHomePhoneNumber = customerHomePhoneNumber;
	}

	public String getCustomerMobilePhoneNumber() {
		return CustomerMobilePhoneNumber;
	}

	public void setCustomerMobilePhoneNumber(String customerMobilePhoneNumber) {
		CustomerMobilePhoneNumber = customerMobilePhoneNumber;
	}

	public String getCustomerHomeAddress() {
		return CustomerHomeAddress;
	}

	public void setCustomerHomeAddress(String customerHomeAddress) {
		CustomerHomeAddress = customerHomeAddress;
	}

	public String getCustomerEmail() {
		return CustomerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		CustomerEmail = customerEmail;
	}

	public String getCustomerCardID() {
		return CustomerCardID;
	}

	public void setCustomerCardID(String customerCardID) {
		CustomerCardID = customerCardID;
	}

	public Customer getCorrespondingCustomer() {
		return CorrespondingCustomer;
	}

	public void setCorrespondingCustomer(Customer correspondingCustomer) {
		CorrespondingCustomer = correspondingCustomer;
	}
	
	

}
