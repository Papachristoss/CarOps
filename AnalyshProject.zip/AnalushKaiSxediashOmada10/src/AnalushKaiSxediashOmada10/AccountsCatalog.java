package AnalushKaiSxediashOmada10;

import java.util.ArrayList;

public class AccountsCatalog {

	private ArrayList<Account> AccountsCatalog;

	
	
	public AccountsCatalog() {
		super();
		AccountsCatalog = new ArrayList<Account>();
	}
	
	public AccountsCatalog(ArrayList<Account> accountsCatalog) {
		super();
		AccountsCatalog = accountsCatalog;
	}

	
	public ArrayList<Account> getAccountsCatalog() {
		return AccountsCatalog;
	}

	public void setAccountsCatalog(ArrayList<Account> accountsCatalog) {
		AccountsCatalog = accountsCatalog;
	}
	
	
}
