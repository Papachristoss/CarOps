package AnalushKaiSxediashOmada10;

import java.util.ArrayList;

public class CatalogOfVehicleCards {

	private ArrayList<VehicleCard> VehicleCardsCatalog;

	
	public CatalogOfVehicleCards() {
		super();
		VehicleCardsCatalog = new ArrayList<VehicleCard>();
	}
	
	
	public CatalogOfVehicleCards(ArrayList<VehicleCard> vehicleCardsCatalog) {
		super();
		VehicleCardsCatalog = vehicleCardsCatalog;
	}
	
	

	public ArrayList<VehicleCard> getVehicleCardsCatalog() {
		return VehicleCardsCatalog;
	}

	public void setVehicleCardsCatalog(ArrayList<VehicleCard> vehicleCardsCatalog) {
		VehicleCardsCatalog = vehicleCardsCatalog;
	}


	public void addVehicleCard(VehicleCard vehicleCard) {
		// TODO Auto-generated method stub
		this.VehicleCardsCatalog.add(vehicleCard);
	}
	
	
}
