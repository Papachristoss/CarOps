package AnalushKaiSxediashOmada10;

public class ReceptionMechanicAccount extends MechanicAccount {

	public ReceptionMechanicAccount(Employee owner, String username, String password, String type) {
		super(owner, username, password, type);
		// TODO Auto-generated constructor stub
	}

}
