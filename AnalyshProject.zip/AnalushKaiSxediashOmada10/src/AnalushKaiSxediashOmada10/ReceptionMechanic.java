package AnalushKaiSxediashOmada10;

public class ReceptionMechanic extends Mechanic {

	public ReceptionMechanic() {
		// TODO Auto-generated constructor stub
	}

	public ReceptionMechanic(String name, String surname, String mobilePhoneNumber, String homePhoneNumber,
			String homeAddress, String emailAddress, String birthDate, String aFM, int yearsWorkingInCurrentBusiness,
			int yearsOfExperience, String employmentRole, double salary, String cV, boolean experienced) {
		super(name, surname, mobilePhoneNumber, homePhoneNumber, homeAddress, emailAddress, birthDate, aFM,
				yearsWorkingInCurrentBusiness, yearsOfExperience, employmentRole, salary, cV, experienced);
		// TODO Auto-generated constructor stub
	}

	public ReceptionMechanic(String name, String surname, String mobilePhoneNumber, String homePhoneNumber,
			String homeAddress, String emailAddress, String birthDate, String aFM, int yearsWorkingInCurrentBusiness,
			int yearsOfExperience, String employmentRole, double salary, String cV) {
		super(name, surname, mobilePhoneNumber, homePhoneNumber, homeAddress, emailAddress, birthDate, aFM,
				yearsWorkingInCurrentBusiness, yearsOfExperience, employmentRole, salary, cV);
		// TODO Auto-generated constructor stub
	}

	public void PerformVehicleAssessment(Vehicle Vehicle) {
		//Does Vehicle Assessment
	}
	
	public RepairsFolder CreateRepairsFolder() {
		//Creates RepairsFolder 
		RepairsFolder CreatedRepairsFolder = new RepairsFolder();
		return CreatedRepairsFolder;
	}
	
	public void AddTaskNeededForRepair(RepairsFolder RepairsFolder,Task Task) {
		//Adds Passed Task to Passed RepairsFolder
		RepairsFolder.AddTask(Task);
		
	}
	
	public void SubmitRepairsFolder(RepairsFolder RepairsFolder) {
		//SubmitsRepairsFolder
	}
}
