package AnalushKaiSxediashOmada10;

public class PaymentReceipt {

	private String PaymentID;
	private double PaymentAmount;
	private String PaymentDate;
	private String PaymentAFM;
	
	private Payment CorrespondingPayment;
	
	
	public PaymentReceipt(String paymentID, double paymentAmount, String paymentDate, String paymentAFM) {
		super();
		PaymentID = paymentID;
		PaymentAmount = paymentAmount;
		PaymentDate = paymentDate;
		PaymentAFM = paymentAFM;
	}
	
	
	public String getPaymentID() {
		return PaymentID;
	}
	public void setPaymentID(String paymentID) {
		PaymentID = paymentID;
	}
	public double getPaymentAmount() {
		return PaymentAmount;
	}
	public void setPaymentAmount(double paymentAmount) {
		PaymentAmount = paymentAmount;
	}
	public String getPaymentDate() {
		return PaymentDate;
	}
	public void setPaymentDate(String paymentDate) {
		PaymentDate = paymentDate;
	}
	public String getPaymentAFM() {
		return PaymentAFM;
	}
	public void setPaymentAFM(String paymentAFM) {
		PaymentAFM = paymentAFM;
	}


	public Payment getCorrespondingPayment() {
		return CorrespondingPayment;
	}

	public void setCorrespondingPayment(Payment correspondingPayment) {
		CorrespondingPayment = correspondingPayment;
	}
	
	
}
