package AnalushKaiSxediashOmada10;

import java.util.ArrayList;

public class CatalogOfCustomerCards {

	private ArrayList<CustomerCard> CustomerCardsCatalog;

	
	public CatalogOfCustomerCards() {
		super();
		CustomerCardsCatalog = new ArrayList<CustomerCard>();
	}
	
	
	public CatalogOfCustomerCards(ArrayList<CustomerCard> customerCardsCatalog) {
		super();
		CustomerCardsCatalog = customerCardsCatalog;
	}
	
	

	public ArrayList<CustomerCard> getCustomerCardsCatalog() {
		return CustomerCardsCatalog;
	}

	public void setCustomerCardsCatalog(ArrayList<CustomerCard> customerCardsCatalog) {
		CustomerCardsCatalog = customerCardsCatalog;
	}
	
	
}
