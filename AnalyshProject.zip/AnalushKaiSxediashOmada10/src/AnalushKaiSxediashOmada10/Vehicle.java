package AnalushKaiSxediashOmada10;

public class Vehicle {

	private String Name;
	private String Brand;
	private String CreationYear;
	private int CC;
	private int BHP;
	private double Kilometers;
	
	private VehicleCard CorespondingVehicleCard;
	private Customer VehicleOwner;


	public Vehicle(String name, String brand, String creationYear, int cC, int bHP, double kilometers) {
		super();
		Name = name;
		Brand = brand;
		CreationYear = creationYear;
		CC = cC;
		BHP = bHP;
		Kilometers = kilometers;
	}
	
	
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	
	public String getBrand() {
		return Brand;
	}
	public void setBrand(String brand) {
		Brand = brand;
	}
	
	public String getCreationYear() {
		return CreationYear;
	}
	public void setCreationYear(String creationYear) {
		CreationYear = creationYear;
	}
	
	public int getCC() {
		return CC;
	}
	public void setCC(int cC) {
		CC = cC;
	}
	
	public int getBHP() {
		return BHP;
	}
	public void setBHP(int bHP) {
		BHP = bHP;
	}
	
	public double getKilometers() {
		return Kilometers;
	}
	public void setKilometers(double kilometers) {
		Kilometers = kilometers;
	}
	
	public VehicleCard getCorespondingVehicleCard() {
		return CorespondingVehicleCard;
	}
	public void setCorespondingVehicleCard(VehicleCard corespondingVehicleCard) {
		CorespondingVehicleCard = corespondingVehicleCard;
	}



	public Customer getVehicleOwner() {
		return VehicleOwner;
	}



	public void setVehicleOwner(Customer vehicleOwner) {
		VehicleOwner = vehicleOwner;
	}

	
}
