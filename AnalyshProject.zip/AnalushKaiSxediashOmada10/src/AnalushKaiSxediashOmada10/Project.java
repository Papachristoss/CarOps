package AnalushKaiSxediashOmada10;

import java.util.ArrayList;
import java.util.Objects;

public class Project {
	
	
	private double TasksCost;
	private String StartDate;
	private String EndDate;
	private double SellCost;
	private int CodeID;
	
	
	private ArrayList<Task> ergasies = new ArrayList();
	private ArrayList<String> onomataAntalaktikon = new ArrayList();
	private int TotalManHours;
	
	
	
	
	
	public double getTasksCost() {
		return TasksCost;
	}
	public void setTasksCost(double tasksCost) {
		TasksCost = tasksCost;
	}
	public String getStartDate() {
		return StartDate;
	}
	public void setStartDate(String startDate) {
		StartDate = startDate;
	}
	public String getEndDate() {
		return EndDate;
	}
	public void setEndDate(String endDate) {
		EndDate = endDate;
	}
	public double getSellCost() {
		return SellCost;
	}
	public void setSellCost(double sellCost) {
		SellCost = sellCost;
	}
	public int getCodeID() {
		return CodeID;
	}
	public void setCodeID(int codeID) {
		CodeID = codeID;
	}
	public ArrayList<Task> getErgasies() {
		return ergasies;
	}
	public void setErgasies(ArrayList<Task> ergasies) {
		this.ergasies = ergasies;
	}
	public ArrayList<String> getOnomataAntalaktikon() {
		return onomataAntalaktikon;
	}
	public void setOnomataAntalaktikon(ArrayList<String> onomataAntalaktikon) {
		this.onomataAntalaktikon = onomataAntalaktikon;
	}
	public int getTotalManHours() {
		return TotalManHours;
	}
	public void setTotalManHours(int totalManHours) {
		TotalManHours = totalManHours;
	}
	@Override
	public int hashCode() {
		return Objects.hash(CodeID, EndDate, SellCost, StartDate, TasksCost, TotalManHours, ergasies,
				onomataAntalaktikon);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Project other = (Project) obj;
		return CodeID == other.CodeID && Objects.equals(EndDate, other.EndDate)
				&& Double.doubleToLongBits(SellCost) == Double.doubleToLongBits(other.SellCost)
				&& Objects.equals(StartDate, other.StartDate)
				&& Double.doubleToLongBits(TasksCost) == Double.doubleToLongBits(other.TasksCost)
				&& TotalManHours == other.TotalManHours && Objects.equals(ergasies, other.ergasies)
				&& Objects.equals(onomataAntalaktikon, other.onomataAntalaktikon);
	}
	public void addItem(String item) {
		onomataAntalaktikon.add(item);
	}
	public int getDuration() {
		return TotalManHours;
	}

	public void setDuration(int duration) {
		this.TotalManHours = duration;
	}

	public void addItem(Task ergasia) {
		ergasies.add(ergasia);
	}
	
	public double getTotalCost() {
		double cost = 0;
		for(Task ergasia: ergasies) {
			cost +=ergasia.totalCost();
		}
		return cost;
	}
	public void itemNames() {
		for(String item : onomataAntalaktikon) {
			System.out.println(item);
		}
			
	}
	
}
