package AnalushKaiSxediashOmada10;

import java.util.ArrayList;

public class Manager extends Human {

	private String Role;
	private String AFM;
	
	
	public Manager(String name, String surname, String mobilePhoneNumber, String homePhoneNumber, String homeAddress,
			String emailAddress, String birthDate, String role, String aFM) {
		super(name, surname, mobilePhoneNumber, homePhoneNumber, homeAddress, emailAddress, birthDate);
		Role = role;
		AFM = aFM;
	}

	public Manager(String name, String surname, String mobilePhoneNumber, String homePhoneNumber, String homeAddress,
			String emailAddress, String birthDate) {
		super(name, surname, mobilePhoneNumber, homePhoneNumber, homeAddress, emailAddress, birthDate);
		// TODO Auto-generated constructor stub
	}

	public Manager() {
		// TODO Auto-generated constructor stub
	}

	
	
	//METHODS OF CLASS
	public void ViewMonthlyReports(ArrayList<Report> Reports) {
		//Views Monthly Reports
	}
	public void SelectReportToSee(ArrayList<Report> Reports) {
		//Selects Particular Report to See
	}
	public void SelectMonthOfReport(int month) {
		//Selects Month of report
	}
	public void ReturnToMonthlyReports(){
		//Returns To Monthly Reports Menu
	}
	public void ExitReport() {
		//Exits Reports Menu
	}
	
	
	
	
	//GETTERS AND SETTERS
	public String getRole() {
		return Role;
	}

	public void setRole(String role) {
		Role = role;
	}

	public String getAFM() {
		return AFM;
	}

	public void setAFM(String aFM) {
		AFM = aFM;
	}

	
}
