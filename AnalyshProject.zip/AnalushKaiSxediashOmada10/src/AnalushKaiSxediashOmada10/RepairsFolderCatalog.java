package AnalushKaiSxediashOmada10;

import java.util.ArrayList;

public class RepairsFolderCatalog {

	ArrayList<RepairsFolder> RepairsFolderCatalog;

	
	
	public RepairsFolderCatalog() {
		super();
	}

	public RepairsFolderCatalog(ArrayList<RepairsFolder> repairsFolderCatalog) {
		super();
		RepairsFolderCatalog = repairsFolderCatalog;
	}

	public ArrayList<RepairsFolder> getRepairsFolderCatalog() {
		return RepairsFolderCatalog;
	}

	public void setRepairsFolderCatalog(ArrayList<RepairsFolder> repairsFolderCatalog) {
		RepairsFolderCatalog = repairsFolderCatalog;
	}
	
	
}
