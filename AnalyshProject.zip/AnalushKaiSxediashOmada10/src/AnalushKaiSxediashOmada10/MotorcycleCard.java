package AnalushKaiSxediashOmada10;

public class MotorcycleCard extends VehicleCard{

	private int CC;
	

	public MotorcycleCard(String vehiclePlateNumber, String vehicleBrand, String vehicleModel,
			String vehicleCreationYear, String vehicleCardID, int cc) {
		super(vehiclePlateNumber, vehicleBrand, vehicleModel, vehicleCreationYear, vehicleCardID);
		// TODO Auto-generated constructor stub
		CC = cc;
		}

	
	public int getCC() {
		return CC;
	}

	public void setCC(int cC) {
		CC = cC;
	}
	

}
