package AnalushKaiSxediashOmada10;

public class Account {

	private Employee Owner;
	private String Username;
	private String Password;
	private String Type;
	
	
	public Account(Employee owner, String username, String password, String type) {
		super();
		Owner = owner;
		Username = username;
		Password = password;
		Type = type;
	}
	
	
	public Account() {
		// TODO Auto-generated constructor stub
	}


	public Employee getOwner() {
		return Owner;
	}
	public void setOwner(Employee owner) {
		Owner = owner;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	
	
}
