package AnalushKaiSxediashOmada10;

public class Payment {


	private String PaymentID;
	private double PaymentAmount;
	private String PaymentDate;
	private String PaymentMethod;
	
	private PaymentReceipt PaymentReceipt;
	
	public Payment(String paymentID, double paymentAmount, String paymentDate, String paymentMethod) {
		super();
		PaymentID = paymentID;
		PaymentAmount = paymentAmount;
		PaymentDate = paymentDate;
		PaymentMethod = paymentMethod;
	}
	
	
	public String getPaymentID() {
		return PaymentID;
	}
	public void setPaymentID(String paymentID) {
		PaymentID = paymentID;
	}
	public double getPaymentAmount() {
		return PaymentAmount;
	}
	public void setPaymentAmount(double paymentAmount) {
		PaymentAmount = paymentAmount;
	}
	public String getPaymentDate() {
		return PaymentDate;
	}
	public void setPaymentDate(String paymentDate) {
		PaymentDate = paymentDate;
	}
	public String getPaymentAFM() {
		return PaymentMethod;
	}
	public void setPaymentAFM(String paymentAFM) {
		PaymentMethod = paymentAFM;
	}
	
	
}
