package AnalushKaiSxediashOmada10;

public class CarCard extends VehicleCard{

	public CarCard(String vehiclePlateNumber, String vehicleBrand, String vehicleModel, String vehicleCreationYear,
			String vehicleCardID) {
		super(vehiclePlateNumber, vehicleBrand, vehicleModel, vehicleCreationYear, vehicleCardID);
		// TODO Auto-generated constructor stub
	}

}
