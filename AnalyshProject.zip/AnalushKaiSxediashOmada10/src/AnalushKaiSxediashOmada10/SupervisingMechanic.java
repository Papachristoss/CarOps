package AnalushKaiSxediashOmada10;

public class SupervisingMechanic extends Mechanic {

	
	public SupervisingMechanic() {
		// TODO Auto-generated constructor stub
	}

	public SupervisingMechanic(String name, String surname, String mobilePhoneNumber, String homePhoneNumber,
			String homeAddress, String emailAddress, String birthDate, String aFM, int yearsWorkingInCurrentBusiness,
			int yearsOfExperience, String employmentRole, double salary, String cV, boolean experienced) {
		super(name, surname, mobilePhoneNumber, homePhoneNumber, homeAddress, emailAddress, birthDate, aFM,
				yearsWorkingInCurrentBusiness, yearsOfExperience, employmentRole, salary, cV, experienced);
		// TODO Auto-generated constructor stub
	}

	public SupervisingMechanic(String name, String surname, String mobilePhoneNumber, String homePhoneNumber,
			String homeAddress, String emailAddress, String birthDate, String aFM, int yearsWorkingInCurrentBusiness,
			int yearsOfExperience, String employmentRole, double salary, String cV) {
		super(name, surname, mobilePhoneNumber, homePhoneNumber, homeAddress, emailAddress, birthDate, aFM,
				yearsWorkingInCurrentBusiness, yearsOfExperience, employmentRole, salary, cV);
		// TODO Auto-generated constructor stub
	}

	public void AssignTaskToMechanic(Mechanic mechanic, Task task) {
		//Assigns Passed Task To Passed Mechanic  
		mechanic.AssignTaskToMechanic(task);
	}
	
}
