package AnalushKaiSxediashOmada10;

public class SupervisingMechanicAccounts extends MechanicAccount {

	public SupervisingMechanicAccounts(Employee owner, String username, String password, String type) {
		super(owner, username, password, type);
		// TODO Auto-generated constructor stub
	}

}
