package AnalushKaiSxediashOmada10;

public class MechanicAccount extends Account {

	public MechanicAccount(Employee owner, String username, String password, String type) {
		super(owner, username, password, type);
		// TODO Auto-generated constructor stub
	}

}
