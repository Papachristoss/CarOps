package AnalushKaiSxediashOmada10;

public class Secretay extends Employee {

	public Secretay(String name, String surname, String mobilePhoneNumber, String homePhoneNumber, String homeAddress,
			String emailAddress, String birthDate, String aFM, int yearsWorkingInCurrentBusiness, int yearsOfExperience,
			String employmentRole, double salary, String cV) {
		super(name, surname, mobilePhoneNumber, homePhoneNumber, homeAddress, emailAddress, birthDate, aFM,
				yearsWorkingInCurrentBusiness, yearsOfExperience, employmentRole, salary, cV);
		// TODO Auto-generated constructor stub
	}

}
