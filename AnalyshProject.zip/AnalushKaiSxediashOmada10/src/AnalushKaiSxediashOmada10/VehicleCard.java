package AnalushKaiSxediashOmada10;

public class VehicleCard {
	
	private String VehiclePlateNumber;
	private String VehicleBrand;
	private String VehicleModel;
	private String VehicleCreationYear;
	private String VehicleCardID;

	private Vehicle CorespondingVehicle;

	
	
	public VehicleCard(String vehiclePlateNumber, String vehicleBrand, String vehicleModel, String vehicleCreationYear,
			String vehicleCardID) {
		super();
		VehiclePlateNumber = vehiclePlateNumber;
		VehicleBrand = vehicleBrand;
		VehicleModel = vehicleModel;
		VehicleCreationYear = vehicleCreationYear;
		VehicleCardID = vehicleCardID;
	}

	



	public VehicleCard(Vehicle vehicle, VehicleCard vehicleCard) {
		// TODO Auto-generated constructor stub
	}





	public VehicleCard() {
		// TODO Auto-generated constructor stub
	}





	public String getVehiclePlateNumber() {
		return VehiclePlateNumber;
	}

	public void setVehiclePlateNumber(String vehiclePlateNumber) {
		VehiclePlateNumber = vehiclePlateNumber;
	}

	public String getVehicleBrand() {
		return VehicleBrand;
	}

	public void setVehicleBrand(String vehicleBrand) {
		VehicleBrand = vehicleBrand;
	}

	public String getVehicleModel() {
		return VehicleModel;
	}

	public void setVehicleModel(String vehicleModel) {
		VehicleModel = vehicleModel;
	}

	public String getVehicleCreationYear() {
		return VehicleCreationYear;
	}

	public void setVehicleCreationYear(String vehicleCreationYear) {
		VehicleCreationYear = vehicleCreationYear;
	}

	public String getVehicleCardID() {
		return VehicleCardID;
	}

	public void setVehicleCardID(String vehicleCardID) {
		VehicleCardID = vehicleCardID;
	}

	public Vehicle getCorespondingVehicle() {
		return CorespondingVehicle;
	}

	public void setCorespondingVehicle(Vehicle corespondingVehicle) {
		CorespondingVehicle = corespondingVehicle;
	}
	
	
}
