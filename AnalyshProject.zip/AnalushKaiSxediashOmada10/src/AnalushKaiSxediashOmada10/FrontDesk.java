package AnalushKaiSxediashOmada10;

import java.util.ArrayList;

public class FrontDesk {
	
	private ArrayList<Secretay> Secrateries;
	
	
	public FrontDesk() {
		super();
	}

	public FrontDesk(ArrayList<Secretay> secrateries) {
		super();
		Secrateries = secrateries;
	}

	
	
	public Account CreateAccount() {
		Account CreatedAccount=new Account();
		return CreatedAccount;
	}
	
	public VehicleCard CreateVehicleCard(Vehicle vehicle,VehicleCard vehicleCard) {
		VehicleCard CreatedVehicleCard = new VehicleCard(vehicle,vehicleCard);
		return CreatedVehicleCard;
	}
	public CustomerCard CreateCustomerCard() {
		CustomerCard CreatedCustomerCard= new CustomerCard();
		return CreatedCustomerCard;
	}
	public void SearchRepairFolder(RepairsFolder RepairsFolder) {
		//Searches for particular repairs Folder in system 
	}
	public void SelectRepairFolder(RepairsFolder RepairsFolder) {
		//Selects particular repairs Folder in system 
	}
	public void GiveRepairFolderToCustomer() {
		//Secretary Gives Physical Repair Folder to Customer
	}
	public void InformSystemAboutRepair(RepairsFolder RepairsFolder, boolean condition) {
		//System is informed about the state of a repair
	}
	public void InformCustomerOfCompleteRepair(Customer customer,RepairsFolder RepairsFolder) {
		//Secretary informs Customer That Repair is complete 
	}
	public void UpdateRepairAsPaidAndComplete(RepairsFolder RepairsFolder) {
		//Secretary Updates Repair as Paid and done  
	}
	
	
	
	
	
	
	
	public ArrayList<Secretay> getSecrateries() {
		return Secrateries;
	}

	public void setSecrateries(ArrayList<Secretay> secrateries) {
		Secrateries = secrateries;
	}

}
