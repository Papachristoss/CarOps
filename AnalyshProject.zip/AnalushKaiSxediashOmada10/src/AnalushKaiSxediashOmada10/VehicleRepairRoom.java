package AnalushKaiSxediashOmada10;

public class VehicleRepairRoom {

	
	public void EnterVehicleForRepair(Vehicle vehicle, VehicleCard vehicleCard) {
		//method that enters vehicles for repair
	}
	
	
}
