package AnalushKaiSxediashOmada10;

public class Human {
	
	private String Name;
	private String Surname;
	private String MobilePhoneNumber;
	private String HomePhoneNumber;
	private String HomeAddress;
	private String EmailAddress;
	private String BirthDate;
	
	
	public Human(String name,String surname, String mobilePhoneNumber, String homePhoneNumber, String homeAddress,
			String emailAddress, String birthDate) {
		super();
		Name=name;
		Surname = surname;
		MobilePhoneNumber = mobilePhoneNumber;
		HomePhoneNumber = homePhoneNumber;
		HomeAddress = homeAddress;
		EmailAddress = emailAddress;
		BirthDate = birthDate;
	}
	
	public Human() {
		// TODO Auto-generated constructor stub
	}

	public String getSurname() {
		return Surname;
	}
	public void setSurname(String surname) {
		Surname = surname;
	}
	public String getMobilePhoneNumber() {
		return MobilePhoneNumber;
	}
	public void setMobilePhoneNumber(String mobilePhoneNumber) {
		MobilePhoneNumber = mobilePhoneNumber;
	}
	public String getHomePhoneNumber() {
		return HomePhoneNumber;
	}
	public void setHomePhoneNumber(String homePhoneNumber) {
		HomePhoneNumber = homePhoneNumber;
	}
	public String getHomeAddress() {
		return HomeAddress;
	}
	public void setHomeAddress(String homeAddress) {
		HomeAddress = homeAddress;
	}
	public String getEmailAddress() {
		return EmailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		EmailAddress = emailAddress;
	}
	public String getBirthDate() {
		return BirthDate;
	}
	public void setBirthDate(String birthDate) {
		BirthDate = birthDate;
	}
	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
	
}
