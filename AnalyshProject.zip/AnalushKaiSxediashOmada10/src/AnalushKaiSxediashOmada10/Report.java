package AnalushKaiSxediashOmada10;

public class Report {

	private String Month;
	private String Data;
	private String Type;
	
	
	public Report() {
		super();
	}
	public Report(String month, String data, String type) {
		super();
		Month = month;
		Data = data;
		Type = type;
	}
	
	public String getMonth() {
		return Month;
	}
	public void setMonth(String month) {
		Month = month;
	}
	public String getData() {
		return Data;
	}
	public void setData(String data) {
		Data = data;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	} 
	
	
}
