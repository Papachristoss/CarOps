package AnalushKaiSxediashOmada10;

public class Motorcycle extends Vehicle{

	public Motorcycle(String name, String brand, String creationYear, int cC, int bHP, double kilometers) {
		super(name, brand, creationYear, cC, bHP, kilometers);
		// TODO Auto-generated constructor stub
	}

}
