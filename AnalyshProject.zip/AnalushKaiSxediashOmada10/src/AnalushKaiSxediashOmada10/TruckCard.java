package AnalushKaiSxediashOmada10;

public class TruckCard extends VehicleCard{

	public TruckCard(String vehiclePlateNumber, String vehicleBrand, String vehicleModel, String vehicleCreationYear,
			String vehicleCardID,int payload) {
		super(vehiclePlateNumber, vehicleBrand, vehicleModel, vehicleCreationYear, vehicleCardID);
		// TODO Auto-generated constructor stub
		Payload = payload;
	}

	private int Payload;
	
	public int getPayload() {
		return Payload;
	}

	public void setPayload(int payload) {
		Payload = payload;
	}
}
