package AnalushKaiSxediashOmada10;

public class Employee extends Human{
	
	private String AFM;
	private int YearsWorkingInCurrentBusiness;
	private int YearsOfExperience;
	private String EmploymentRole;
	private double Salary;
	private String CV;


	public Employee(String name, String surname, String mobilePhoneNumber, String homePhoneNumber, String homeAddress,
			String emailAddress, String birthDate, String aFM, int yearsWorkingInCurrentBusiness, int yearsOfExperience,
			String employmentRole, double salary, String cV) {
		super(name, surname, mobilePhoneNumber, homePhoneNumber, homeAddress, emailAddress, birthDate);
		AFM = aFM;
		YearsWorkingInCurrentBusiness = yearsWorkingInCurrentBusiness;
		YearsOfExperience = yearsOfExperience;
		EmploymentRole = employmentRole;
		Salary = salary;
		CV = cV;
	}


	public Employee() {
		// TODO Auto-generated constructor stub
		super();
	}


	public String getAFM() {
		return AFM;
	}

	public void setAFM(String aFM) {
		AFM = aFM;
	}

	public int getYearsWorkingInCurrentBusiness() {
		return YearsWorkingInCurrentBusiness;
	}

	public void setYearsWorkingInCurrentBusiness(int yearsWorkingInCurrentBusiness) {
		YearsWorkingInCurrentBusiness = yearsWorkingInCurrentBusiness;
	}

	public int getYearsOfExperience() {
		return YearsOfExperience;
	}

	public void setYearsOfExperience(int yearsOfExperience) {
		YearsOfExperience = yearsOfExperience;
	}

	public String getEmploymentRole() {
		return EmploymentRole;
	}

	public void setEmploymentRole(String employmentRole) {
		EmploymentRole = employmentRole;
	}

	public double getSalary() {
		return Salary;
	}

	public void setSalary(double salary) {
		Salary = salary;
	}

	public String getCV() {
		return CV;
	}

	public void setCV(String cV) {
		CV = cV;
	}

	
}
