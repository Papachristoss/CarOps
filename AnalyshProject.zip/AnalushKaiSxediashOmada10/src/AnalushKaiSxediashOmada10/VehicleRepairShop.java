package AnalushKaiSxediashOmada10;

import java.util.ArrayList;

public class VehicleRepairShop {

	private String BrandName;
	private String GeographicalAddress;
	private String PhoneNumber;
	private String BusinessAFM;
	
	private ArrayList<Customer> RepairShopCustomers;
	private ArrayList<Employee> RepairShopEmployees;
	private VehicleRepairRoom RepairRoom;
	private InformationSystem RepairShopInformationSystem;
	
	

	public VehicleRepairShop(String brandName, String geographicalAddress, String phoneNumber, String businessAFM) {
		super();
		BrandName = brandName;
		GeographicalAddress = geographicalAddress;
		PhoneNumber = phoneNumber;
		BusinessAFM = businessAFM;
	}
	
	
	
	public String getBrandName() {
		return BrandName;
	}
	public void setBrandName(String brandName) {
		BrandName = brandName;
	}
	public String getGeographicalAddress() {
		return GeographicalAddress;
	}
	public void setGeographicalAddress(String geographicalAddress) {
		GeographicalAddress = geographicalAddress;
	}
	public String getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	public String getBusinessAFM() {
		return BusinessAFM;
	}
	public void setBusinessAFM(String businessAFM) {
		BusinessAFM = businessAFM;
	}



	public ArrayList<Customer> getRepairShopCustomers() {
		return RepairShopCustomers;
	}



	public void setRepairShopCustomers(ArrayList<Customer> repairShopCustomers) {
		RepairShopCustomers = repairShopCustomers;
	}



	public ArrayList<Employee> getRepairShopEmployees() {
		return RepairShopEmployees;
	}



	public void setRepairShopEmployees(ArrayList<Employee> repairShopEmployees) {
		RepairShopEmployees = repairShopEmployees;
	}



	public VehicleRepairRoom getRepairRoom() {
		return RepairRoom;
	}



	public void setRepairRoom(VehicleRepairRoom repairRoom) {
		RepairRoom = repairRoom;
	}
	
	
	
}
